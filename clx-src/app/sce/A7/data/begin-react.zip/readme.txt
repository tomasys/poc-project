터미널에서 npm install 커맨드로 패키지에 있는 노드모듈을 받습니다.

노드 모듈을 다 받고난 후 터미널에서 npm start 하면 localhost:3000으로 서버가 열립니다.