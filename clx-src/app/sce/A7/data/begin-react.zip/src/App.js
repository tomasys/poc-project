import React, { useEffect, useState } from "react";
import "./App.css";
import { AgGridReact } from "ag-grid-react"; //그리드컨트롤
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useTable } from "react-table"; //폼레아아웃 컨트롤 

function App() {
 
  const [rowData,setRowData] = useState([]);
  const [filterText,setFilterText] = useState("");
  let gridApi = null;
  const onFilterTextChange = (value) => {
    setFilterText(value);
    gridApi.setQuickFilter(value);
  }
  const onGridReady = (params) => {
    gridApi = params.api;
  };
  useEffect(() => {
    //메시지 이벤트 리스너
    window.addEventListener("message", (event) => {
      
      const types = event.data.type;
      const data = event.data.data;
      if(types == "filter") {
        onFilterTextChange(data);
      } else if(types == "data") {
        setRowData(data);
      }
     
    });
  }, []);

  //그리드 만드는 스크립트
  const columnDefs = [
    { headerName: "ID", field: "id", width: "80px" },
    { headerName: "FIRST_NAME", field: "first_name", resizable: true, flex: 1 },
    { headerName: "LAST_NAME", field: "last_name", resizable: true, flex: 1 },
    { headerName: "EMAIL", field: "email", resizable: true, flex: 1 },
    { headerName: "GENDER", field: "gender", resizable: true, flex: 1 },
    { headerName: "UNIVERSITY", field: "university", resizable: true, flex: 1 }
  ];

  const [selectedRowData, setSelectedRowData] = useState(null);

  const handleRowClicked = (event) => {
    setSelectedRowData(event.data);
  };

  const emptyRowData = {
    id: "",
    first_name: "",
    last_name: "",
    email: "",
    gender: "",
    university: ""
  };

  //그리드 랜더링 하는곳
  return (
    <div className="app-container">
      <h2>Grid</h2>
      <div className="ag-theme-alpine" style={{ height: "400px", width: "100%" }}>
        <AgGridReact
          rowData={rowData}
          columnDefs={columnDefs}
          onRowClicked={handleRowClicked}
          onGridReady={onGridReady}
        />
      </div>
      <div className="row-data-table">
        <h2>Selected Row Data</h2>
        <RowDataTable rowData={selectedRowData || emptyRowData} />
      </div>
    </div>
  );
}

//테이블 레이아웃 스크립트
const RowDataTable = ({ rowData }) => {
  const columns = React.useMemo(
    () => [
      { Header: "columnNm", accessor: "attribute" },
      { Header: "Data", accessor: "value" }
    ],
    []
  );

  const data = React.useMemo(() => {
    return Object.entries(rowData).map(([key, value]) => ({
      attribute: key,
      value: value || ""
    }));
  }, [rowData]);

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow
  } = useTable({ columns, data });

  //테이블 랜더링 하는곳
  return (
    <table {...getTableProps()}>
      <thead>
        {headerGroups.map((headerGroup) => (
          <tr {...headerGroup.getHeaderGroupProps()}>
            {headerGroup.headers.map((column) => (
              <th {...column.getHeaderProps()}>{column.render("Header")}</th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows.map((row) => {
          prepareRow(row);
          return (
            <tr {...row.getRowProps()}>
              {row.cells.map((cell) => (
                <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
              ))}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export default App;